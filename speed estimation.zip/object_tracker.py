from io import open
import requests
import shutil
from zipfile import ZipFile
from imageai.Prediction.Custom import ModelTraining, CustomImagePrediction
import os
import re

execution_path = os.getcwd()




def train_traffic_net():
    

    trainer = ModelTraining()
    trainer.setModelTypeAsResNet()
    trainer.setDataDirectory("dataset")
    trainer.trainModel(num_objects=2, num_experiments=20, batch_size=20, save_full_model=True, enhance_data=True)

def run_predict():
    predictor = CustomImagePrediction()
    predictor.setModelPath(model_path="./dataset/models/model_ex-020_acc-0.838889.h5")
    predictor.setJsonPath(model_json="model_class.json")
    predictor.loadFullModel(num_objects=2)
    def sorted_alphanumeric(data):
        convert = lambda text: int(text) if text.isdigit() else text.lower()
        alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ] 
        return sorted(data, key=alphanum_key)
    arr=list(sorted_alphanumeric(os.listdir("./dataset/test/sparse_traffic/")))
    counter=0
    for st in arr:
        
        predictions, probabilities = predictor.classifyImage(image_input="./dataset/test/sparse_traffic/"+st)

        dic={}
        for k,j in zip(predictions,probabilities):
            dic[k]=j
        print(st,dic)
        if dic["Accident"]>40:
            counter=counter+1
    print(counter)
    # return dic
    
        

#Un-comment the line below to train your model
# train_traffic_net()

(run_predict())
#Un-comment the line below to run predictions

# import cv2
# cap = cv2.VideoCapture('aaa.mp4')
# count = 0
# counter=0
# b=True
# while cap.isOpened():
#     ret,frame = cap.read()
    
# # #     # cv2.imshow('window-name', frame)
#     cv2.imwrite("./ss/frame%d.jpg" % count, frame)
#     x=run_predict("./ss/frame%d.jpg" % count)
#     if x["Accident"]>65:
#         counter=counter+1
#     else:
#         if(b):
#             counter=0
    
#     image = cv2.imread("./ss/frame%d.jpg" % count)
#     if counter>=15:
#         b=False
#         window_name = 'Image'
#         font = cv2.FONT_HERSHEY_SIMPLEX
#         org = (200, 200)
#         fontScale = 5
#         color = (0, 0, 255)
#         thickness = 5
#         image = cv2.putText(image, 'Accident', org, font, fontScale, color, thickness, cv2.LINE_AA)
#     height, width, layers = frame.shape  
#     (cv2.imwrite("./ss/frame%d.jpg" % count,image))
#     count = count + 1
#     if cv2.waitKey(10) & 0xFF == ord('q'):
#         break
# # print("counter:",counter)
# cap.release()
# cv2.destroyAllWindows() # destroy all opened windows


